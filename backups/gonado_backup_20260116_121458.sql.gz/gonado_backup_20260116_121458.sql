--
-- PostgreSQL database dump
--

\restrict 0ptvPDGbl45uEOB2qr7sZQoJirEXMqPDuVCp4BcwxlTlERQzohYCkT1yytTiPdr

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: activitytargettype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.activitytargettype AS ENUM (
    'goal',
    'node',
    'user',
    'update',
    'badge'
);


ALTER TYPE public.activitytargettype OWNER TO gonado;

--
-- Name: activitytype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.activitytype AS ENUM (
    'goal_created',
    'node_completed',
    'goal_completed',
    'comment_added',
    'reaction_added',
    'started_following',
    'badge_earned',
    'milestone_reached'
);


ALTER TYPE public.activitytype OWNER TO gonado;

--
-- Name: badgecategory; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.badgecategory AS ENUM (
    'achievement',
    'social',
    'streak',
    'milestone',
    'special'
);


ALTER TYPE public.badgecategory OWNER TO gonado;

--
-- Name: badgerarity; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.badgerarity AS ENUM (
    'common',
    'rare',
    'epic',
    'legendary'
);


ALTER TYPE public.badgerarity OWNER TO gonado;

--
-- Name: commenttargettype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.commenttargettype AS ENUM (
    'node',
    'update',
    'goal'
);


ALTER TYPE public.commenttargettype OWNER TO gonado;

--
-- Name: conversationstatus; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.conversationstatus AS ENUM (
    'active',
    'waiting',
    'planning',
    'completed',
    'abandoned'
);


ALTER TYPE public.conversationstatus OWNER TO gonado;

--
-- Name: dependencytype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.dependencytype AS ENUM (
    'finish_to_start',
    'start_to_start',
    'finish_to_finish'
);


ALTER TYPE public.dependencytype OWNER TO gonado;

--
-- Name: followtype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.followtype AS ENUM (
    'user',
    'goal'
);


ALTER TYPE public.followtype OWNER TO gonado;

--
-- Name: goalstatus; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.goalstatus AS ENUM (
    'PLANNING',
    'ACTIVE',
    'COMPLETED',
    'ABANDONED'
);


ALTER TYPE public.goalstatus OWNER TO gonado;

--
-- Name: goalvisibility; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.goalvisibility AS ENUM (
    'PUBLIC',
    'PRIVATE',
    'SHARED',
    'FRIENDS'
);


ALTER TYPE public.goalvisibility OWNER TO gonado;

--
-- Name: interactiontype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.interactiontype AS ENUM (
    'comment',
    'reaction'
);


ALTER TYPE public.interactiontype OWNER TO gonado;

--
-- Name: messagerole; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.messagerole AS ENUM (
    'user',
    'assistant',
    'system'
);


ALTER TYPE public.messagerole OWNER TO gonado;

--
-- Name: nodestatus; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.nodestatus AS ENUM (
    'LOCKED',
    'ACTIVE',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public.nodestatus OWNER TO gonado;

--
-- Name: nodetype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.nodetype AS ENUM (
    'task',
    'parallel_start',
    'parallel_end',
    'milestone'
);


ALTER TYPE public.nodetype OWNER TO gonado;

--
-- Name: queuestatus; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.queuestatus AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed'
);


ALTER TYPE public.queuestatus OWNER TO gonado;

--
-- Name: sharepermission; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.sharepermission AS ENUM (
    'VIEW',
    'EDIT'
);


ALTER TYPE public.sharepermission OWNER TO gonado;

--
-- Name: sharestatus; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.sharestatus AS ENUM (
    'PENDING',
    'ACCEPTED',
    'DECLINED'
);


ALTER TYPE public.sharestatus OWNER TO gonado;

--
-- Name: swapstatus; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.swapstatus AS ENUM (
    'proposed',
    'accepted',
    'in_progress',
    'completed',
    'declined',
    'cancelled'
);


ALTER TYPE public.swapstatus OWNER TO gonado;

--
-- Name: targettype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.targettype AS ENUM (
    'node',
    'update',
    'goal'
);


ALTER TYPE public.targettype OWNER TO gonado;

--
-- Name: unlocktype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.unlocktype AS ENUM (
    'date',
    'node_complete'
);


ALTER TYPE public.unlocktype OWNER TO gonado;

--
-- Name: updatetype; Type: TYPE; Schema: public; Owner: gonado
--

CREATE TYPE public.updatetype AS ENUM (
    'progress',
    'milestone',
    'struggle',
    'celebration'
);


ALTER TYPE public.updatetype OWNER TO gonado;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.activities (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    activity_type public.activitytype NOT NULL,
    target_type public.activitytargettype,
    target_id uuid,
    extra_data jsonb NOT NULL,
    is_public boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.activities OWNER TO gonado;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO gonado;

--
-- Name: badges; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.badges (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    icon_url character varying(500),
    criteria jsonb NOT NULL,
    xp_reward integer NOT NULL,
    category public.badgecategory NOT NULL,
    rarity public.badgerarity NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.badges OWNER TO gonado;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.comments (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    target_type public.commenttargettype NOT NULL,
    target_id uuid NOT NULL,
    parent_id uuid,
    content text NOT NULL,
    is_edited boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.comments OWNER TO gonado;

--
-- Name: conversation_messages; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.conversation_messages (
    id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    role public.messagerole NOT NULL,
    content text NOT NULL,
    sequence integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.conversation_messages OWNER TO gonado;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.conversations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    status public.conversationstatus,
    goal_id uuid,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.conversations OWNER TO gonado;

--
-- Name: follows; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.follows (
    id uuid NOT NULL,
    follower_id uuid NOT NULL,
    follow_type public.followtype NOT NULL,
    target_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.follows OWNER TO gonado;

--
-- Name: generation_queue; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.generation_queue (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    goal_text text NOT NULL,
    status public.queuestatus NOT NULL,
    goal_id uuid,
    generated_plan json,
    error_message text,
    created_at timestamp without time zone NOT NULL,
    processing_started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.generation_queue OWNER TO gonado;

--
-- Name: goal_shares; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.goal_shares (
    id uuid NOT NULL,
    goal_id uuid NOT NULL,
    shared_with_user_id uuid NOT NULL,
    invited_by_id uuid NOT NULL,
    permission public.sharepermission NOT NULL,
    status public.sharestatus NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.goal_shares OWNER TO gonado;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.goals (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    category character varying(50),
    visibility public.goalvisibility NOT NULL,
    status public.goalstatus NOT NULL,
    world_theme character varying(50) NOT NULL,
    target_date timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    current_mood character varying(50),
    mood_updated_at timestamp without time zone,
    struggle_detected_at timestamp without time zone,
    struggle_dismissed_at timestamp without time zone,
    no_progress_threshold_days integer,
    hard_node_threshold_days integer
);


ALTER TABLE public.goals OWNER TO gonado;

--
-- Name: interactions; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.interactions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    target_type public.targettype NOT NULL,
    target_id uuid NOT NULL,
    interaction_type public.interactiontype NOT NULL,
    content text,
    reaction_type character varying(50),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.interactions OWNER TO gonado;

--
-- Name: node_dependencies; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.node_dependencies (
    id uuid NOT NULL,
    node_id uuid NOT NULL,
    depends_on_id uuid NOT NULL,
    dependency_type public.dependencytype NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.node_dependencies OWNER TO gonado;

--
-- Name: nodes; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.nodes (
    id uuid NOT NULL,
    goal_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    "order" integer NOT NULL,
    status public.nodestatus NOT NULL,
    node_type public.nodetype NOT NULL,
    can_parallel boolean NOT NULL,
    is_sequential boolean NOT NULL,
    parallel_group integer,
    estimated_duration integer,
    difficulty integer NOT NULL,
    position_x double precision NOT NULL,
    position_y double precision NOT NULL,
    extra_data jsonb NOT NULL,
    due_date timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.nodes OWNER TO gonado;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    message text,
    data jsonb NOT NULL,
    read boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO gonado;

--
-- Name: prophecies; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.prophecies (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    goal_id uuid NOT NULL,
    predicted_date date NOT NULL,
    accuracy_days integer,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.prophecies OWNER TO gonado;

--
-- Name: resource_drops; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.resource_drops (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    node_id uuid NOT NULL,
    message text,
    resources jsonb NOT NULL,
    is_opened boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    opened_at timestamp without time zone
);


ALTER TABLE public.resource_drops OWNER TO gonado;

--
-- Name: sacred_boosts; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.sacred_boosts (
    id uuid NOT NULL,
    giver_id uuid NOT NULL,
    receiver_id uuid NOT NULL,
    goal_id uuid NOT NULL,
    message text,
    boost_date date NOT NULL,
    year_month integer NOT NULL,
    xp_awarded integer NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.sacred_boosts OWNER TO gonado;

--
-- Name: swaps; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.swaps (
    id uuid NOT NULL,
    proposer_id uuid NOT NULL,
    receiver_id uuid NOT NULL,
    proposer_goal_id uuid NOT NULL,
    proposer_node_id uuid,
    receiver_goal_id uuid,
    receiver_node_id uuid,
    message character varying(500),
    status public.swapstatus NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.swaps OWNER TO gonado;

--
-- Name: time_capsules; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.time_capsules (
    id uuid NOT NULL,
    sender_id uuid NOT NULL,
    node_id uuid NOT NULL,
    content text NOT NULL,
    unlock_type public.unlocktype NOT NULL,
    unlock_date timestamp with time zone,
    is_unlocked boolean NOT NULL,
    unlocked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.time_capsules OWNER TO gonado;

--
-- Name: updates; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.updates (
    id uuid NOT NULL,
    node_id uuid NOT NULL,
    user_id uuid NOT NULL,
    content text NOT NULL,
    media_urls character varying[] NOT NULL,
    update_type public.updatetype NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.updates OWNER TO gonado;

--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.user_badges (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    badge_id uuid NOT NULL,
    earned_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_badges OWNER TO gonado;

--
-- Name: user_stats; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.user_stats (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    goals_created integer NOT NULL,
    goals_completed integer NOT NULL,
    nodes_completed integer NOT NULL,
    comments_given integer NOT NULL,
    reactions_given integer NOT NULL,
    comments_received integer NOT NULL,
    reactions_received integer NOT NULL,
    followers_count integer NOT NULL,
    following_count integer NOT NULL,
    achiever_score integer NOT NULL,
    supporter_score integer NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_stats OWNER TO gonado;

--
-- Name: users; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    username character varying(50) NOT NULL,
    display_name character varying(100),
    avatar_url character varying(500),
    bio text,
    xp integer NOT NULL,
    level integer NOT NULL,
    streak_days integer NOT NULL,
    streak_last_activity timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO gonado;

--
-- Name: xp_transactions; Type: TABLE; Schema: public; Owner: gonado
--

CREATE TABLE public.xp_transactions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    amount integer NOT NULL,
    reason character varying(200) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.xp_transactions OWNER TO gonado;

--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.activities (id, user_id, activity_type, target_type, target_id, extra_data, is_public, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.alembic_version (version_num) FROM stdin;
13performance_indexes
\.


--
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.badges (id, name, description, icon_url, criteria, xp_reward, category, rarity, created_at) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.comments (id, user_id, target_type, target_id, parent_id, content, is_edited, created_at, updated_at) FROM stdin;
b911ed5e-456f-4078-ad44-ae796bcc2837	284c355f-b655-4e58-8953-84c3fb60972f	node	28c66db7-9039-47ae-8227-4f2e8d771e0f	\N	dsfgdfsgdsf	f	2026-01-16 11:17:32.0184	2026-01-16 11:17:32.018402
\.


--
-- Data for Name: conversation_messages; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.conversation_messages (id, conversation_id, role, content, sequence, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.conversations (id, user_id, status, goal_id, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.follows (id, follower_id, follow_type, target_id, created_at) FROM stdin;
\.


--
-- Data for Name: generation_queue; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.generation_queue (id, user_id, goal_text, status, goal_id, generated_plan, error_message, created_at, processing_started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: goal_shares; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.goal_shares (id, goal_id, shared_with_user_id, invited_by_id, permission, status, created_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.goals (id, user_id, title, description, category, visibility, status, world_theme, target_date, created_at, updated_at, current_mood, mood_updated_at, struggle_detected_at, struggle_dismissed_at, no_progress_threshold_days, hard_node_threshold_days) FROM stdin;
dcd1da1b-e957-4b06-b677-06adfe310202	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	Test Goal for Resource Drops	A test goal to test resource drops	\N	PUBLIC	PLANNING	mountain	\N	2026-01-16 10:40:14.352263	2026-01-16 10:40:14.352266	\N	\N	\N	\N	7	14
dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	Test Goal for Resource Drops	A test goal to test resource drops	\N	PUBLIC	PLANNING	mountain	\N	2026-01-16 10:40:20.035288	2026-01-16 10:40:20.035291	\N	\N	\N	\N	7	14
29f19676-530f-4ea9-add1-72770f381c6f	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	Test Goal for E2E	A goal to test reactions, comments, and resources	\N	PUBLIC	PLANNING	mountain	\N	2026-01-16 10:42:15.569638	2026-01-16 10:42:15.569641	\N	\N	\N	\N	7	14
\.


--
-- Data for Name: interactions; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.interactions (id, user_id, target_type, target_id, interaction_type, content, reaction_type, created_at) FROM stdin;
ca609ca2-4097-41b3-8a3f-d701eae27d93	0627e499-aa01-424a-80bd-9690ac85872a	node	28c66db7-9039-47ae-8227-4f2e8d771e0f	reaction	\N	encourage	2026-01-16 11:20:33.543083
\.


--
-- Data for Name: node_dependencies; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.node_dependencies (id, node_id, depends_on_id, dependency_type, created_at) FROM stdin;
\.


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.nodes (id, goal_id, title, description, "order", status, node_type, can_parallel, is_sequential, parallel_group, estimated_duration, difficulty, position_x, position_y, extra_data, due_date, completed_at, created_at) FROM stdin;
28c66db7-9039-47ae-8227-4f2e8d771e0f	dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4	Test Node 1	First test node	1	LOCKED	task	f	t	\N	\N	3	0	0	{}	\N	\N	2026-01-16 10:40:36.135927
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.notifications (id, user_id, type, title, message, data, read, created_at) FROM stdin;
b33ac3fe-eb99-4929-aac8-18dd775b920d	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	resource_drop	e2etest dropped a resource	New resource on 'Test Node 1': Test resource drop	{"drop_id": "584dea37-976f-42d9-b6aa-f96cb86a0f10", "goal_id": "dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4", "node_id": "28c66db7-9039-47ae-8227-4f2e8d771e0f", "goal_title": "Test Goal for Resource Drops", "node_title": "Test Node 1", "dropper_username": "e2etest"}	f	2026-01-16 10:55:09.633518
763709ad-75a6-4020-9160-62e785035c8b	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	resource_drop	e2etest dropped a resource	New resource on 'Test Node 1': Test resource	{"drop_id": "e9258e88-a6d6-43ad-898d-df60076f0395", "goal_id": "dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4", "node_id": "28c66db7-9039-47ae-8227-4f2e8d771e0f", "goal_title": "Test Goal for Resource Drops", "node_title": "Test Node 1", "dropper_username": "e2etest"}	f	2026-01-16 10:57:16.068131
863bce88-9947-4f60-a008-73bc5d5a62a6	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	resource_drop	e2etest dropped a resource	New resource on 'Test Node 1': Test resource	{"drop_id": "3de3f9e0-aaf7-45ae-ab7c-15fb1652ea9d", "goal_id": "dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4", "node_id": "28c66db7-9039-47ae-8227-4f2e8d771e0f", "goal_title": "Test Goal for Resource Drops", "node_title": "Test Node 1", "dropper_username": "e2etest"}	f	2026-01-16 11:00:02.44359
4e0bba16-2d9c-4d75-a1be-2a4041ee43b7	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	resource_drop	e2etest dropped a resource	New resource on 'Test Node 1': Test message 1768561232198	{"drop_id": "157e74f2-5959-4e96-9510-146aeab21973", "goal_id": "dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4", "node_id": "28c66db7-9039-47ae-8227-4f2e8d771e0f", "goal_title": "Test Goal for Resource Drops", "node_title": "Test Node 1", "dropper_username": "e2etest"}	f	2026-01-16 11:00:33.186726
41afe86d-90f6-407a-8578-a4780329df27	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	resource_drop	e2etest dropped a resource	New resource on 'Test Node 1': Check it out!	{"drop_id": "e744d0c2-e5e1-44bb-bb37-34c7f4354d06", "goal_id": "dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4", "node_id": "28c66db7-9039-47ae-8227-4f2e8d771e0f", "goal_title": "Test Goal for Resource Drops", "node_title": "Test Node 1", "dropper_username": "e2etest"}	f	2026-01-16 11:00:37.646768
8979df44-dc24-419e-8bfb-a9c61a5ed632	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	resource_drop	e2etest dropped a resource	New resource on 'Test Node 1': Check it out!	{"drop_id": "1a5ca8be-6830-4751-b5db-1197eb9694d6", "goal_id": "dec48a4f-06dc-4cfe-8df7-4ce6b76a16c4", "node_id": "28c66db7-9039-47ae-8227-4f2e8d771e0f", "goal_title": "Test Goal for Resource Drops", "node_title": "Test Node 1", "dropper_username": "e2etest"}	f	2026-01-16 11:01:37.588918
\.


--
-- Data for Name: prophecies; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.prophecies (id, user_id, goal_id, predicted_date, accuracy_days, created_at) FROM stdin;
\.


--
-- Data for Name: resource_drops; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.resource_drops (id, user_id, node_id, message, resources, is_opened, created_at, opened_at) FROM stdin;
584dea37-976f-42d9-b6aa-f96cb86a0f10	0627e499-aa01-424a-80bd-9690ac85872a	28c66db7-9039-47ae-8227-4f2e8d771e0f	Test resource drop	[{"url": "https://example.com/resource", "type": "link", "title": "Test Resource"}]	f	2026-01-16 10:55:09.589172	\N
e9258e88-a6d6-43ad-898d-df60076f0395	0627e499-aa01-424a-80bd-9690ac85872a	28c66db7-9039-47ae-8227-4f2e8d771e0f	Test resource	[{"url": "https://example.com/test", "type": "link", "title": "Test Link"}]	f	2026-01-16 10:57:16.039295	\N
3de3f9e0-aaf7-45ae-ab7c-15fb1652ea9d	0627e499-aa01-424a-80bd-9690ac85872a	28c66db7-9039-47ae-8227-4f2e8d771e0f	Test resource	[{"url": "https://example.com/test", "type": "link", "title": "Test Link"}]	f	2026-01-16 11:00:02.430374	\N
157e74f2-5959-4e96-9510-146aeab21973	0627e499-aa01-424a-80bd-9690ac85872a	28c66db7-9039-47ae-8227-4f2e8d771e0f	Test message 1768561232198	[{"url": "https://example.com/test-1768561232198", "type": "link", "title": "E2E Test Resource 1768561232198"}]	f	2026-01-16 11:00:33.055593	\N
e744d0c2-e5e1-44bb-bb37-34c7f4354d06	0627e499-aa01-424a-80bd-9690ac85872a	28c66db7-9039-47ae-8227-4f2e8d771e0f	\N	[{"url": "https://example.com/count-1768561237168", "type": "link", "title": "Count Test 1768561237168"}]	f	2026-01-16 11:00:37.620955	\N
1a5ca8be-6830-4751-b5db-1197eb9694d6	0627e499-aa01-424a-80bd-9690ac85872a	28c66db7-9039-47ae-8227-4f2e8d771e0f	\N	[{"url": "not-a-valid-url", "type": "link", "title": "Test Title"}]	f	2026-01-16 11:01:37.564795	\N
\.


--
-- Data for Name: sacred_boosts; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.sacred_boosts (id, giver_id, receiver_id, goal_id, message, boost_date, year_month, xp_awarded, created_at) FROM stdin;
\.


--
-- Data for Name: swaps; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.swaps (id, proposer_id, receiver_id, proposer_goal_id, proposer_node_id, receiver_goal_id, receiver_node_id, message, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: time_capsules; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.time_capsules (id, sender_id, node_id, content, unlock_type, unlock_date, is_unlocked, unlocked_at, created_at) FROM stdin;
\.


--
-- Data for Name: updates; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.updates (id, node_id, user_id, content, media_urls, update_type, created_at) FROM stdin;
\.


--
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.user_badges (id, user_id, badge_id, earned_at) FROM stdin;
\.


--
-- Data for Name: user_stats; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.user_stats (id, user_id, goals_created, goals_completed, nodes_completed, comments_given, reactions_given, comments_received, reactions_received, followers_count, following_count, achiever_score, supporter_score, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.users (id, email, password_hash, username, display_name, avatar_url, bio, xp, level, streak_days, streak_last_activity, created_at, updated_at) FROM stdin;
0627e499-aa01-424a-80bd-9690ac85872a	e2etest@example.com	$2b$12$4SdpbMe/BGsnh4NMiU/G1ef9fvxg6S8YS1KPTC9SVRiduGlOrggK.	e2etest	e2etest	\N	\N	0	1	0	\N	2026-01-16 10:39:46.440893	2026-01-16 10:39:46.440897
284c355f-b655-4e58-8953-84c3fb60972f	admin@gonado.app	$2b$12$ZQzqquuzcGitjSVhUQnoIe4TccpmfWdn6Zit4ssQiPJisVjd3uJ7q	admin	admin	\N	\N	0	1	0	\N	2026-01-16 10:39:52.158023	2026-01-16 10:39:52.158027
0ca3c17b-65bf-43b3-a4b1-76975ae18b68	testuser@example.com	$2b$12$2krcGo930FT51m9rzppW8.SHsafJKw3a9RQu18c0yDTeLLYtciKBS	testuser	testuser	\N	\N	100	2	0	\N	2026-01-16 10:39:51.056312	2026-01-16 10:40:14.393544
\.


--
-- Data for Name: xp_transactions; Type: TABLE DATA; Schema: public; Owner: gonado
--

COPY public.xp_transactions (id, user_id, amount, reason, created_at) FROM stdin;
503b6c45-c5a7-4b62-bd3b-40b86942c2c4	0ca3c17b-65bf-43b3-a4b1-76975ae18b68	100	First goal created	2026-01-16 10:40:14.358128
\.


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: badges badges_name_key; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_name_key UNIQUE (name);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: conversation_messages conversation_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: generation_queue generation_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.generation_queue
    ADD CONSTRAINT generation_queue_pkey PRIMARY KEY (id);


--
-- Name: goal_shares goal_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goal_shares
    ADD CONSTRAINT goal_shares_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: interactions interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_pkey PRIMARY KEY (id);


--
-- Name: node_dependencies node_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.node_dependencies
    ADD CONSTRAINT node_dependencies_pkey PRIMARY KEY (id);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: prophecies prophecies_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.prophecies
    ADD CONSTRAINT prophecies_pkey PRIMARY KEY (id);


--
-- Name: resource_drops resource_drops_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.resource_drops
    ADD CONSTRAINT resource_drops_pkey PRIMARY KEY (id);


--
-- Name: sacred_boosts sacred_boosts_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.sacred_boosts
    ADD CONSTRAINT sacred_boosts_pkey PRIMARY KEY (id);


--
-- Name: swaps swaps_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_pkey PRIMARY KEY (id);


--
-- Name: time_capsules time_capsules_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.time_capsules
    ADD CONSTRAINT time_capsules_pkey PRIMARY KEY (id);


--
-- Name: follows unique_follow; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT unique_follow UNIQUE (follower_id, follow_type, target_id);


--
-- Name: goal_shares unique_goal_share; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goal_shares
    ADD CONSTRAINT unique_goal_share UNIQUE (goal_id, shared_with_user_id);


--
-- Name: updates updates_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.updates
    ADD CONSTRAINT updates_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: user_stats user_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_pkey PRIMARY KEY (id);


--
-- Name: user_stats user_stats_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: xp_transactions xp_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.xp_transactions
    ADD CONSTRAINT xp_transactions_pkey PRIMARY KEY (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: gonado
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: gonado
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: activities activities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: comments comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.comments(id);


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: conversation_messages conversation_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: conversations conversations_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: conversations conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: follows follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id);


--
-- Name: generation_queue generation_queue_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.generation_queue
    ADD CONSTRAINT generation_queue_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: generation_queue generation_queue_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.generation_queue
    ADD CONSTRAINT generation_queue_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: goal_shares goal_shares_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goal_shares
    ADD CONSTRAINT goal_shares_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE CASCADE;


--
-- Name: goal_shares goal_shares_invited_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goal_shares
    ADD CONSTRAINT goal_shares_invited_by_id_fkey FOREIGN KEY (invited_by_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goal_shares goal_shares_shared_with_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goal_shares
    ADD CONSTRAINT goal_shares_shared_with_user_id_fkey FOREIGN KEY (shared_with_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: interactions interactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: node_dependencies node_dependencies_depends_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.node_dependencies
    ADD CONSTRAINT node_dependencies_depends_on_id_fkey FOREIGN KEY (depends_on_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: node_dependencies node_dependencies_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.node_dependencies
    ADD CONSTRAINT node_dependencies_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: nodes nodes_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: prophecies prophecies_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.prophecies
    ADD CONSTRAINT prophecies_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE CASCADE;


--
-- Name: prophecies prophecies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.prophecies
    ADD CONSTRAINT prophecies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: resource_drops resource_drops_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.resource_drops
    ADD CONSTRAINT resource_drops_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: resource_drops resource_drops_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.resource_drops
    ADD CONSTRAINT resource_drops_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sacred_boosts sacred_boosts_giver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.sacred_boosts
    ADD CONSTRAINT sacred_boosts_giver_id_fkey FOREIGN KEY (giver_id) REFERENCES public.users(id);


--
-- Name: sacred_boosts sacred_boosts_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.sacred_boosts
    ADD CONSTRAINT sacred_boosts_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE CASCADE;


--
-- Name: sacred_boosts sacred_boosts_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.sacred_boosts
    ADD CONSTRAINT sacred_boosts_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: swaps swaps_proposer_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_proposer_goal_id_fkey FOREIGN KEY (proposer_goal_id) REFERENCES public.goals(id);


--
-- Name: swaps swaps_proposer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_proposer_id_fkey FOREIGN KEY (proposer_id) REFERENCES public.users(id);


--
-- Name: swaps swaps_proposer_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_proposer_node_id_fkey FOREIGN KEY (proposer_node_id) REFERENCES public.nodes(id);


--
-- Name: swaps swaps_receiver_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_receiver_goal_id_fkey FOREIGN KEY (receiver_goal_id) REFERENCES public.goals(id);


--
-- Name: swaps swaps_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: swaps swaps_receiver_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.swaps
    ADD CONSTRAINT swaps_receiver_node_id_fkey FOREIGN KEY (receiver_node_id) REFERENCES public.nodes(id);


--
-- Name: time_capsules time_capsules_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.time_capsules
    ADD CONSTRAINT time_capsules_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: time_capsules time_capsules_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.time_capsules
    ADD CONSTRAINT time_capsules_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: updates updates_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.updates
    ADD CONSTRAINT updates_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id);


--
-- Name: updates updates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.updates
    ADD CONSTRAINT updates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id);


--
-- Name: user_badges user_badges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_stats user_stats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: xp_transactions xp_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gonado
--

ALTER TABLE ONLY public.xp_transactions
    ADD CONSTRAINT xp_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 0ptvPDGbl45uEOB2qr7sZQoJirEXMqPDuVCp4BcwxlTlERQzohYCkT1yytTiPdr

